SOURCE_DIR = "/usr2/hpc/Projects/IntelDeliverable/PySchedCL/pyschedcl/"
CPU_PLATFORM = ["Intel(R) OpenCL","AMD Accelerated Parallel Processing"]
NUM_CPU_DEVICES =  2
GPU_PLATFORM = ["NVIDIA CUDA"]
NUM_GPU_DEVICES =  4
